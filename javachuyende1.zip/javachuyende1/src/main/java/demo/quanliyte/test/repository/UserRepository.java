package demo.quanliyte.test.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import demo.quanliyte.test.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {

}
